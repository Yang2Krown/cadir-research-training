# HSC 结果小包

准入实现提交：6cc7b3da67c193da11a67c45a75167d6521438b0。

独立设计审查提交：[GitHub commit](https://github.com/Yang2Krown/cadir-research-training/commit/2d2565c24b3958260d7232ff03f211c06bd2e845)；阶段一和 C04 范围说明位于包内 `results/design-admission/`。

结果归档提交：[GitHub commit](https://github.com/Yang2Krown/cadir-research-training/commit/091a8a4585cabc59a5504380398892bac49044f4)；仓库路径 `cases/nestorowa_hsc/fair-experiment/results/6cc7b3d-20261027-attempt-01` 对应包内 `results/`。

独立结果复验：[签字提交](https://github.com/Yang2Krown/cadir-research-training/commit/b48066cba0bf4cd308f2f75b1134c12f85c576ef)，decision 为 `PASS_LIMITED_RESULT_ACCEPTANCE`；完整报告和复验记录位于包内 `reviews/result-review/`。

结果树中的实际结果报告、展示状态和终端记录保留为 091a8a4 提交时的原样快照；其中‘待复验’是当时状态，之后由上述已签 reviewer decision 与文稿记录取代。签署报告和历史快照均未改写。

中文结果段落和 PPT 讲稿位于包内 `documents/`。来源获取记录说明原始输入为本会话重新获取，不是缺失历史原件的恢复。ZIP 只放入结果树中的非 RDS 文件；全部 RDS、raw 和共同预处理对象不进入 ZIP，精确外置路径、字节数和 SHA-256 见 external-objects.tsv。Mac 看板未同步，用户本机完整备份尚未验证；此小包不替代完整原始数据备份。
